/**
 * Devoir mis à jour pour l'étude de cas du 08/11/2024 - Elyes Ghouaiel avec Killian Chenal
 */

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';

// Interface définissant la structure des détails d'un Pokémon
interface PokemonDetail {
  name: string;
  type: string;
  // Ajoutez d'autres propriétés si nécessaire
}

function DetailPokemon({ id }: { id: number }) {
  // États pour stocker les détails du Pokémon, l'état de chargement et les erreurs
  const [data, setData] = useState<PokemonDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Effet pour récupérer les détails du Pokémon lorsque l'ID change
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true); // Démarre le chargement
        // Appel API pour récupérer les détails du Pokémon par ID
        const response = await axios.post<PokemonDetail>('http://localhost:8000/Pokemon/detail', {
          id: id
        });
        setData(response.data); // Met à jour l'état avec les données reçues
        setError(null); // Réinitialise l'erreur
      } catch (error) {
        console.error("Erreur lors de la récupération des données:", error);
        setError("Impossible de charger les détails du Pokémon."); // Définit un message d'erreur
      } finally {
        setLoading(false); // Arrête le chargement
      }
    };

    fetchData(); // Appelle la fonction pour récupérer les données
  }, [id]); // Dépendance sur l'ID

  // Affiche un message de chargement pendant que les données sont récupérées
  if (loading) {
    return <div className="loading">Chargement des détails du Pokémon...</div>;
  }

  // Affiche un message d'erreur si une erreur s'est produite lors de la récupération des données
  if (error) {
    return <div className="error">{error}</div>;
  }

  // Affiche un message si aucune donnée n'est disponible pour le Pokémon
  if (!data) {
    return <div className="error">Aucune donnée disponible pour ce Pokémon.</div>;
  }

  // Rendu des détails du Pokémon
  return (
    <div className="pokemon-detail">
      <h1>Détail du Pokémon</h1>
      <h2>{data.name}</h2>
      <div className="pokemon-detail-info">
        <p>Type: <span className="pokemon-detail-type">{data.type}</span></p>
        {/* Ajoutez d'autres détails du Pokémon ici */}
      </div>
    </div>
  );
}

export default DetailPokemon;

/**
 * Ce composant React affiche les détails d'un Pokémon spécifique.
 * Il utilise un appel API pour récupérer les informations basées sur l'ID passé en prop.
 * Le composant gère également l'état de chargement et les erreurs potentielles lors de la récupération des données.
 */