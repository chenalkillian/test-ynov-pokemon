/**
 * Devoir mis à jour pour l'étude de cas du 08/11/2024 - Elyes Ghouaiel avec Killian Chenal
 */

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';
import DetailPokemon from './DetailPokemon';

// Interface définissant la structure d'un Pokémon
interface Pokemon {
  id: number;
  name: string;
  type: string;
}

function App() {
  // États pour gérer les données et l'interface utilisateur
  const [data, setData] = useState<Pokemon[]>([]);
  const [newPokemonName, setNewPokemonName] = useState('');
  const [newPokemonType, setNewPokemonType] = useState('');
  const [editingPokemon, setEditingPokemon] = useState<Pokemon | null>(null);
  const [selectedPokemonId, setSelectedPokemonId] = useState<number | null>(null);

  // Effet pour charger les données au montage du composant
  useEffect(() => {
    fetchData();
  }, []);

  // Fonction pour récupérer tous les Pokémon depuis l'API
  const fetchData = async () => {
    try {
      const response = await axios.get<Pokemon[]>('http://localhost:8000/Pokemon/showall');
      setData(response.data);
    } catch (error) {
      console.error("Erreur lors de la récupération des données:", error);
    }
  };

  // Fonction pour ajouter un nouveau Pokémon
  const addPokemon = async () => {
    try {
      const response = await axios.post('http://localhost:8000/Pokemon/add', {
        name: newPokemonName,
        type: newPokemonType
      });
      console.log(response.data);
      setNewPokemonName('');
      setNewPokemonType('');
      await fetchData();
    } catch (error) {
      console.error("Erreur lors de l'ajout du Pokémon:", error);
    }
  };

  // Fonction pour supprimer un Pokémon
  const deletePokemon = async (id: number) => {
    try {
      const response = await axios.post('http://localhost:8000/Pokemon/delete', { id: id });
      console.log(response.data.message);
      await fetchData();
    } catch (error) {
      console.error("Erreur lors de la suppression du Pokémon:", error);
    }
  };

  // Fonction pour commencer l'édition d'un Pokémon
  const startEditing = (pokemon: Pokemon) => {
    setEditingPokemon({ ...pokemon });
  };

  // Fonction pour annuler l'édition
  const cancelEditing = () => {
    setEditingPokemon(null);
  };

  // Fonction pour mettre à jour un Pokémon
  const updatePokemon = async () => {
    if (editingPokemon) {
      try {
        const response = await axios.put('http://localhost:8000/Pokemon/update', editingPokemon);
        console.log(response.data.message);
        setEditingPokemon(null);
        await fetchData();
      } catch (error) {
        console.error("Erreur lors de la modification du Pokémon:", error);
      }
    }
  };

  // Fonction pour revenir à la liste des Pokémon
  const backToList = () => {
    setSelectedPokemonId(null);
  };

  // Rendu du composant
  return (
    <div className="App">
      <h1>Pokédex</h1>
      
      {/* Formulaire d'ajout de Pokémon */}
      <div className="add-pokemon">
        <input 
          type="text" 
          value={newPokemonName} 
          onChange={(e) => setNewPokemonName(e.target.value)} 
          placeholder="Nom du nouveau Pokémon"
        />
        <input 
          type="text" 
          value={newPokemonType} 
          onChange={(e) => setNewPokemonType(e.target.value)} 
          placeholder="Type du nouveau Pokémon"
        />
        <button onClick={addPokemon}>Ajouter un Pokémon</button>
      </div>

      {/* Affichage des détails d'un Pokémon ou de la liste des Pokémon */}
      {selectedPokemonId ? (
        <>
          <button className="back-button" onClick={backToList}>Retour à la liste</button>
          <DetailPokemon id={selectedPokemonId} />
        </>
      ) : (
        <ul className="pokemon-list">
          {data.map((pokemon) => (
            <li key={pokemon.id} className={`pokemon-card ${editingPokemon && editingPokemon.id === pokemon.id ? 'editing' : ''}`}>
            {editingPokemon && editingPokemon.id === pokemon.id ? (
              <>
                <input
                  type="text"
                  value={editingPokemon.name}
                  onChange={(e) => setEditingPokemon({ ...editingPokemon, name: e.target.value })}
                />
                <input
                  type="text"
                  value={editingPokemon.type}
                  onChange={(e) => setEditingPokemon({ ...editingPokemon, type: e.target.value })}
                />
                <div className="separator"></div>
                <div className="button-group">
                  <button onClick={updatePokemon}>Sauvegarder</button>
                  <button onClick={cancelEditing}>Annuler</button>
                </div>
              </>
            ) : (
              <>
                <div className="pokemon-info">
                  <strong>{pokemon.name}</strong> - {pokemon.type}
                </div>
                <div className="separator"></div>
                <div className="button-group">
                  <button onClick={() => setSelectedPokemonId(pokemon.id)}>Détail</button>
                  <button onClick={() => startEditing(pokemon)}>Modifier</button>
                  <button onClick={() => deletePokemon(pokemon.id)}>Supprimer</button>
                </div>
              </>
            )}
          </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;

/**
 * Ce composant React représente l'application principale du Pokédex.
 * Il gère l'affichage de la liste des Pokémon, l'ajout de nouveaux Pokémon,
 * la modification et la suppression des Pokémon existants, ainsi que
 * l'affichage des détails d'un Pokémon spécifique.
 * Le composant utilise des appels API pour interagir avec le backend
 * et maintient l'état local pour gérer l'interface utilisateur.
 */